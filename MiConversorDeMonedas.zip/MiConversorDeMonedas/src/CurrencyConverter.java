import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.io.IOException;
import java.util.Scanner;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class CurrencyConverter {

    private static final String API_KEY = "c5c1df4a0747824382373851";
    private static final String BASE_URL = "https://v6.exchangerate-api.com/v6/";

    public static double obtenerTasaDeCambio(String baseCurrency, String targetCurrency) throws IOException, InterruptedException {
        String url = BASE_URL + API_KEY + "/latest/" + baseCurrency;
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new IOException("Error en la solicitud a la API de tasas de cambio");
        }

        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(response.body(), JsonObject.class);
        double tasaDeCambio = jsonObject
                .getAsJsonObject("conversion_rates")
                .get(targetCurrency)
                .getAsDouble();

        return tasaDeCambio;
    }

    public static double convertirDivisa(double cantidad, double tasaDeCambio) {
        return cantidad * tasaDeCambio;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingresa la divisa base (por ejemplo, USD): ");
        String baseCurrency = scanner.nextLine();

        System.out.print("Ingresa la divisa objetivo (por ejemplo, EUR): ");
        String targetCurrency = scanner.nextLine();

        System.out.print("Ingresa la cantidad a convertir: ");
        double cantidad = scanner.nextDouble();

        try {
            double tasaDeCambio = obtenerTasaDeCambio(baseCurrency, targetCurrency);
            double cantidadConvertida = convertirDivisa(cantidad, tasaDeCambio);
            System.out.printf("%.2f %s son %.2f %s%n", cantidad, baseCurrency, cantidadConvertida, targetCurrency);
        } catch (IOException | InterruptedException e) {
            System.err.println("Ha ocurrido un error: " + e.getMessage());
        }
        scanner.close();
    }
}
